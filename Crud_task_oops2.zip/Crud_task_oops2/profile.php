<?php 
include('db_config.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>





    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-5 mb-3">View Record</h1>

                    

                    <div class="form-group">
                        <label>Name :</label>
                        <p><b><?php echo $r['st_fname']. " " .$r['St_lname']; ?></b></p>
                    </div>

                    <div class="form-group">
                        <label>Full Name:</label>
                        <p><b><?php echo $row["age"]; ?></b></p>
                    </div>

                    <div class="form-group">
                        <label>Gender :</label>
                        <p><b><?php echo $row["gender"]; ?></b></p>
                    </div>

                    <div class="form-group">
                        <label>Mobile :</label>
                        <p><b><?php echo $row["mobile"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Email:</label>
                        <p><b><?php echo $row["email"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Country :</label>
                        <p><b><?php echo $row["country"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Address (Parmant Address) :</label>
                        <p><b><?php echo $row["address1"]; ?></b></p>
                    </div>
                    <div class="form-group">
                        <label>Salary :</label>
                        <p><b><?php echo $row["salary"]; ?></b></p>
                    </div>
                    <p><a href="home.php" class="btn btn-primary">Dashboard</a></p>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
