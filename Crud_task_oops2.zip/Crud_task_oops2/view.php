<?php
require 'db_config.php';
$res = $db->get_data();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GET DATA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    
<table cellpadding="0" cellspacing="0" class="display table table-bordered" id="hidden-table-info" >
    <tbody>
    <tr>
        <th>Student ID</th>
        <th>Student Name</th>
        <th>Student Email</th>
        <th>Student Class</th>
        <th>Student Fees</th>
        <th>Student Mobile</th>
        <th>Student Comment</th>
        <th>Action</th>

    </tr>
  
  <?php 

 while ($r= mysqli_fetch_assoc($res)){

?>
  <tr>
    <td><?php echo $r['id']; ?></td>
    <td><?php echo $r['st_fname']. " " .$r['St_lname']; ?></td>
    <td><?php echo $r['st_email'];?></td>
    <td><?php echo $r['st_class'];?></td>
    <td><?php echo $r['st_fees'];?></td>
    <td><?php echo $r['st_mobile'];?></td>
    <td><?php echo $r['st_comment'];?></td>
    <td>
      <a href="update.php?id=<?php echo $r['id']; ?>">Update</a><br>
      <a href="delete.php?id=<?php echo $r['id']; ?>">Delete</a><br>
      <a href="profile.php?id=<?php echo $r['id']; ?>">View Profile</a>          
    </td>
  </tr>
<?php 
  }
?>
  
    </tbody>
</table>
 </div>


</body>
</html>

