<?php
session_start();
include "const.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Insert Form</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
	<?php
	require 'class.php';  
	$data = new Database();
    
		$fileName = $_FILES["image"]["name"];
		$file_name = $_FILES["document"]["name"];
		$flag = true;

	  if(isset($_POST["submit"])){  
			 
				$projectName = $data->test_input($_POST["project_name"]);
			
				$milestone = $data->test_input($_POST["milestone"]);
			 
				$deliverydate = $data->test_input($_POST["delivery_date"]);
			
				$amount = $data->test_input($_POST["amount"]);
			 
				$desc = $data->test_input($_POST["project_description"]);
			
				$paymentmile = $data->test_input($_POST["payment_milestone"]);
			 
				$paymentfor = $data->test_input($_POST["payment_for"]);
 
       // validation for image ///

				if(empty($fileName)){
					$img = "";

			        $_SESSION['image'] ="Image field is empty";
			        $flag = false;
				}
				else
				{

					   $file_ext=strtolower(end(explode('.',$fileName)));
      
				        $extensions= array("jpeg","jpg","png");
				      
				      if(in_array($file_ext,$extensions)=== false){

				         $_SESSION['type'] ="extension not allowed, please choose a jpg or png file.";
                           $flag = false;
				        }else{
							$img = time(). "-" .$fileName;

							$imgeUpload = move_uploaded_file($_FILES["image"]["tmp_name"],'images/'.$img);
							
						  }
				}

				
    /// validation for document//
                   if(!empty($file_name)){
					  $doctfileExt=strtolower(end(explode('.',$file_name)));
      
				      $doctextension= array("pdf");
				      
				      if(in_array($doctfileExt,$doctextension)=== false){

				         $_SESSION['doctype'] ="Sorry, only pdf files are allowed";
                          $flag = false;
				        }else{
							$document = time(). "-" .$file_name;
							$doctupload = move_uploaded_file($_FILES["document"]["tmp_name"],'document/'.$document);

						  }
					}

				if ($imgeUpload){
					$_SESSION["message"] = "Image upload and";

				}else if($doctupload){
					$_SESSION["message"] = "file upload and";

				}else if($imgeUpload && $doctupload){
					$_SESSION["message"] = "image and file both upload and";

				}else{
					$_SESSION["message"] = "not upload file";
				}

					$insert_data = array(  
				   'project_name'  =>  $projectName,  
				   'project_milestone'   =>  $milestone,
				   'project_delivery_date' => $deliverydate,
				   'project_amount' => $amount,
				   'project_description' => $desc,
				   'profile_image' => $img,
				   'project_document' => $document,
				   'project_payment_milestone' => $paymentmile,
				   'project_payment_for' => $paymentfor
			    );
			 
			    if($flag){
					   
				  if($data->insert('tbl_payment_mildstone', $insert_data)){ 
                     	
					$_SESSION['msg']="form submitted successfully";
					  header("location:table.php"); 
				    }else{
                       echo "error";
				  	   
	               }
	            }	
			
		}    
	?>
	<h3 style="text-align:center;">Add MildStone Payment for Gate7</h3>
	<div class="container">
		<div class="form-box">
		 
		  <form class="form-horizontal" method="post" enctype="multipart/form-data">
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
					      <label for="project-name">Project:</label>
					    </div>
					    <div class="col-md-8">
					      <input class="form-control" type="text" name="project_name">
					  </div>
					</div>     
			    </div>
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
					      <label for="milestone">Milestone:</label>
					    </div>
					    <div class="col-md-8">
			      		  <input class="form-control" type="text" name="milestone">
			      		</div>
			      	</div>
			    </div>
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
						    <label for="delivery-date">Delivery Date:</label>
						</div>
						<div class="col-md-8">
			              <input class="form-control" id="delivery_date" type="text" name="delivery_date">
			            </div>
			      	</div>
			    </div>
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
			      			<label for="amount">Amount:</label>
			      		</div>
			      		<div class="col-md-8">
			     			<input class="form-control" id="amount" type="text" name="amount">
			     		</div>
			     	</div>
			    </div>
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
			     		 <label for="project-description">project Description:</label>
			     		</div>
			     		<div class="col-md-8">
			      			<textarea class="form-control" id="project_description" name="project_description"></textarea>
			  			</div>
			     	</div>
			    </div>
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
			    			<label for="profile">Profile Image:</label>
			    		</div>
			    		<div class="col-md-8">
			    			<input type="file" name="image" class="form-control">
			    	        <span><?php if(isset($_SESSION['image'])){echo $_SESSION['image']; unset($_SESSION['image']);}?></span>
			    			<span><?php if(isset($_SESSION['type'])){echo $_SESSION['type']; unset($_SESSION['type']);}?></span>

			    		</div>
			    	</div>
			    </div>
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
			    			<label for="document">Project document:</label>
			    		</div>
			    		<div class="col-md-8">
			    			<input type="file" name="document" class="form-control">
			    			<span><?php if(isset($_SESSION['doctype'])){echo $_SESSION['doctype']; unset($_SESSION['doctype']);}?></span>
			    		</div>
			    	</div>
			    </div>
			     
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
			      			<label for="payment-milestone">Payment Milestone:</label>
			  			</div>
			  			<div class="col-md-8">
					      <select class="form-control" id="payment_milestone" name="payment_milestone">
					      	<?php
					           foreach(PAYMENT_TYPE as $key => $value){?>
					           	<option value="<?php echo $key;?>"><?php echo $value;?></option>
					           	<?php
					           }
					      	?>
					      </select>
					    </div>
					</div>
			    </div>
			    <div class="form-group">
			    	<div class="row">
			    		<div class="col-md-4">
			      			<label for="payment-for">Payment For:</label>
			      		</div>
				      	<div class="col-md-8">
					      <select class="form-control" id="payment_for" name="payment_for">
					      	<?php
					           foreach(PAYMENT_FOR as $key => $value){?>
					           	<option value="<?php echo $key;?>"><?php echo $value;?></option>
					           	<?php
					           }
					      	?>
					      </select>
					 	</div>
				 	</div>
			    </div>
		    	<button type ="submit" class="btn btn-primary" name="submit">submit</button>
		 	</form>
		 </div>
   </div>
</body>
</html>
