<?php
session_start();
class Database{
	private $servername = "phpmyadmin.gipl.inet";
	private $username   = "learning_user";
	private $password   = "learning";
	private $dbname     = "learning_test";

	protected $conn;

	public function __construct(){

		if(!isset($this->conn)){
			$this->conn = new mysqli($this->servername,$this->username,$this->password,$this->dbname);

			if(!$this->conn){
				echo "Database could not connect";
				exit;
			}
		}
		return $this->conn;
	}
    
    public function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
    }

//insert function
	public function insert($table_name,$insert_data){
	$columns = array_keys($insert_data);
    $values = array_values($insert_data);
    $query = "INSERT INTO ".$table_name."(" . implode(', ', $columns) . ") VALUES ('" . implode("', '", $values) . "')";
    
    $result = mysqli_query($this->conn, $query);
    return $result;
	}

//fatch function
	public function showdata($table_name,$where){

    $sql ="SELECT * FROM ".$table_name." where ".$where['wherecondition']." ".$where['order by']." ";
		$result = mysqli_query($this->conn, $sql);
		return $result;
	}

//fatch single data

	public function fatchone($table_name,$where){

       $query = "SELECT * FROM ".$table_name." WHERE " . $where['where']; 
       $result = mysqli_query($this->conn, $query);  
       return $result; 
	}

//update function

	public function update($table_name,$edit_data){

      $query ='';
       foreach($edit_data["edit"] as $key => $value)  
       {  
        $query .= $key . "='".$value."', ";  
       }
       $query = substr($query, 0, -2);  

       $sql = "UPDATE ".$table_name." SET ".$query." WHERE ".$edit_data['id']."";
     // echo $sql;
     // die;
       $result = mysqli_query($this->conn, $sql);
      
       return $result;
    }

//delete function

    public function delete($table_name,$where){
        $query = "DELETE FROM ".$table_name." WHERE ".$where['id']."";  
        $result = mysqli_query($this->conn, $query);
        return $result;
    }
}
   
?>
