<?php 
  	require 'db_config.php';
	 $id = $_GET['id'];

	$result = $db->delete_data($id);
	if($result)
        {
		echo "Delete Success";
		// header('location:index.php');
	}
        else
        {
		echo "OOPs! DATA NOT DELETE";
	}
?>

