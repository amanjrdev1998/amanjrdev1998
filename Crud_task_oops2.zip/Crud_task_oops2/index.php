<?php 
require 'db_config.php';  
$db = new db_student();


if(isset($_POST['Submit']) & !empty($_POST)){

    $stud_first_name = $db->data($_POST['std_fname']) ;

    $stud_last_name =$db->data($_POST['std_lname']);

    $stud_email = $_POST['std_email'];

    $stud_class = $_POST['stud_class'];

    $stud_fees = $_POST['std_fees'];

    $stud_mobile =$_POST['std_mobile'];

    $stud_comment = $_POST['std_comment'];
}

$result = $db->insert_data($stud_first_name ,$stud_last_name ,$stud_email ,$stud_class ,$stud_fees ,$stud_mobile,
    $stud_comment);

    
    if($result)
    {
        echo "success";
        // header('location:index.php');
    }
    else
    {
        echo "OOP! Your Data Not Inserted!".mysqli_connect_error($result);
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD TASK IN PHP</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="form_data"
        style=" max-width: 694px; margin: auto; padding: 50px; background: #ffffff;border: 1px solid;">
        
        <div class="containe">
                <center><h3>SIGN UP FORM</h3></center> 
            <form method="POST" action="" enctype="multipart/form-data" style=" margin: 20px;padding : 20px; ">
                <label for="fname"> Student First Name: </label>
                <input type="text" id="std_fname" name="std_fname" placeholder="Student First Name" />
                <br>
                <label for="lname"> Student Last Name: </label>
                <input type="text" name="std_lname" id="std_lname" placeholder="Student Last Name" />
                <br>
                <label for="email"> Student Email: </label>
                <input type="email" name="std_email" id="std_email" placeholder="Student Email" />
                <br>
                <label for="cars">Select Your Class: </label>
                <select name="stud_class" id="stud_class">
                    <option value="">Select Your Class</option>
                    <option value="class 10">Class X </option>
                    <option value="class 11">Class XI</option>
                    <option value="class 12">Class XII</option>
                </select>
                <br>
                <label for="st_fees"> Student Fees: </label>
                <input type="text" name="std_fees" id="st_fees" placeholder="Student Fees" />
                <br>
                <label for="st_mobile"> Student Mobile No: </label>
                <input type="text" name="std_mobile" id="st_mobile" placeholder=" Student Mobile No. " />
                <br>
                <label for="st_cmt"> Student Comment Box: </label>
                <textarea name="st_comment" id="std_comment" placeholder=" Write Your Comment" cols="20"
                    rows="5"></textarea>
                <br>

                <center><input type="submit" class="btn btn-primary " name="Submit" value="submit" /></center>
            </form>
        </div>
    </div>
</body>

</html>