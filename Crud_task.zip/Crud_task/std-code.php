<?php 
include('db_config.php');


if(isset($_POST['Update']))
{

    $id = mysqli_real_escape_string($db->conn,$_POST['id']);
    $inputData =[
        
        'stud_first_name'=> mysqli_real_escape_string($db->conn,$_POST['st_fname']),
        'stud_last_name'=> mysqli_real_escape_string($db->conn,$_POST['st_lname']),
        'stud_email'=> mysqli_real_escape_string($db->conn,$_POST['st_email']),
        'stud_class'=> mysqli_real_escape_string($db->conn,$_POST['st_class']),
        'stud_fees' => mysqli_real_escape_string($db->conn,$_POST['st_fees']),
        'stud_mobile' => mysqli_real_escape_string($db->conn,$_POST['st_mobile']),
        'stud_comment' => mysqli_real_escape_string($db->conn,$_POST['st_comment']),
    ];

    $result = $db->update_data($inputData,$id);

    if($result)
    {

        echo "Student Update Successfully";
        // header("Location: view.php");

    }
    else
    {
        echo "Student Not Added";
        // header("Location: view.php");
    }
}
?>
