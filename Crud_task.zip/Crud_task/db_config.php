<?php
class db_student{

    public $conn;  
    // public $error;

    public function __construct()  
    {  
		 
				$dbhost='phpmyadmin.gipl.inet';
				$dbusername='learning_user';   
				$dbpass='learning';
				$dbName = "learning_test"; 
				// echo $dbhost."</br>";
				// echo $dbusername."</br>";
				// echo $dbpass."</br>";
				// echo $dbName."</br>";
				
				
				$conn=mysqli_connect($dbhost,$dbusername,$dbpass,$dbName); 
				$this->conn= $conn;

				if(mysqli_connect_error())
				{
					echo "Conection Fail:", mysqli_connect_error();
				}

    }
		public function data($cmd)
		{
			$return = mysqli_real_escape_string($this->conn, $cmd);
			return $return;
			

		}


public function insert_data ($stud_first_name ,$stud_last_name ,$stud_email ,$stud_class ,$stud_fees ,$stud_mobile,
		    $stud_comment){
				
	$sql_insert ="INSERT INTO`crud_task_aman`(st_fname, St_lname, st_email, st_class, st_fees, st_mobile, st_comment) VALUES ('$stud_first_name' ,'$stud_last_name' ,'$stud_email' ,'$stud_class' ,'$stud_fees' ,'$stud_mobile',
				'$stud_comment')";
			$result = mysqli_query($this->conn, $sql_insert);
 			// print_r($result);
			
			if($result)
			{
				return true;
			}
			else
		   {
				return false;
		   }
		}

		public function get_data(){
			$get_sql = "SELECT * FROM `crud_task_aman`";
			// print_r($get_sql);
			// die();
			$res = mysqli_query($this->conn, $get_sql);
			return $res;
		}

		public function delete_data($id){
			$delt_sql ="DELETE FROM `crud_task_aman` WHERE id =$id";
			$del = mysqli_query($this->conn, $delt_sql);
			
			if($del){
				return true;

			}else{
				return false;
			}
			
		}

		//Select for Update query 
		public function edit_select($id)
		{
			$id = mysqli_real_escape_string($this->conn, $id);
			$st_sql =" SELECT * FROM crud_task_aman WHERE id='$id' LIMIT 1";
			$result= $this->conn->query($st_sql);
			if($result->num_rows == 1){
				$data = $result->fetch_assoc();
				return $data;
			}else{
				return false;
			}
		}

		//Update Query
	public function update_data($inputData,$id)
    {
		// print_r($inputData);

		$id = mysqli_real_escape_string($this->conn,$id);
			
		$stud_first_name = $inputData['stud_first_name'];

		$stud_last_name = $inputData['stud_last_name'];
	
		$stud_email = $inputData['stud_email'];
	
		$stud_class = $inputData['stud_class'];
	
		$stud_fees = $inputData['stud_fees'];
	
		$stud_mobile =$inputData['stud_mobile'];
	
		$stud_comment = $inputData['stud_comment'];

		//print_r($inputData);
		
		$upd_student= "UPDATE `crud_task_aman` SET st_fname='$stud_first_name' , st_lname='$stud_last_name' , st_email ='$stud_email' , st_class='$stud_class' , st_fees='$stud_fees' , st_mobile='$stud_mobile' , st_comment ='$stud_comment' WHERE id='$id'";

		
		//  echo "UPDATE `crud_task_aman` SET st_fname='$stud_first_name' , St_lname='$stud_last_name' , st_email ='$stud_email' , st_class='$stud_class' , st_fees='$stud_fees' , st_mobile='$stud_mobile' , st_comment ='$stud_comment' WHERE id='$id'";

		$result = $this->conn->query($upd_student);
			if($result){
				return true;
			}else{
				return false;
			}
    }

}

$db = new db_student();
?>
