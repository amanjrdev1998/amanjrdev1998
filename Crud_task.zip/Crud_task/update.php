<?php 
include('db_config.php');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UPDATE FORM</title>
</head>

<body>
 

    <div class="form_data"
        style=" max-width: 694px; margin: auto; padding: 50px; background: #ffffff;border: 1px solid;">
        <div class="containe">
            <center>
                <h3>UPDATE FORM</h3>
            </center>

            <?php 
   
        if(isset($_GET['id']))
        {
            $id = mysqli_real_escape_string($db->conn,$_GET['id']);
            $result = $db->edit_select($id);
        if($result)
            {
    ?>

            <form method="POST" action="std-code.php" enctype="multipart/form-data" style=" margin: 20px;padding : 20px;">
           
            <input type="hidden" name="id" value="<?=$result['id']?>">

            <label for="fname"> Student First Name: </label>
                <input type="text" id="st_fname" name="st_fname" placeholder="Student First Name"
                    value="<?=$result['st_fname']?>" />
                <br>
                <label for="lname"> Student Last Name: </label>
                <input type="text" name="st_lname" id="st_lname" placeholder="Student Last Name"
                    value="<?=$result['St_lname']?>" />
                <br>
                <label for="email"> Student Email: </label>
                <input type="email" name="st_email" id="st_email" placeholder="Student Email"
                    value="<?=$result['st_email']?>" />
                <br>
                <label for="class">Select Your Class: </label>
                <select name="st_class" id="st_class" value="<?php echo $result['st_class']?>">
                    <option value="">Select Your Class</option>
                    <option value="class 10" <?php if($result["st_class"]=='class 10'){echo "selected";}?>>Class X
                    </option>
                    <option value="class 11" <?php if($result["st_class"]=='class 11'){echo "selected";}?>>Class XI
                    </option>
                    <option value="class 12" <?php if($result["st_class"]=='class 12'){echo "selected";}?>>Class XII
                    </option>
                </select>
                <br>
                <label for="st_fees"> Student Fees: </label>
                <input type="text" name="st_fees" id="std_fees" placeholder="Student Fees"
                    value="<?=$result['st_fees']?>"/>
                <br>
                <label for="st_mobile"> Student Mobile No: </label>
                <input type="text" name="st_mobile" id="st_mobile" placeholder=" Student Mobile No. "
                    value="<?=$result['st_mobile']?>" />
                <br>
                <label for="st_mobile"> Student Comment Box: </label>
                <textarea name="st_comment" id="std_comment" placeholder=" Write Your Comment" cols="20" rows="5"
                    value="<?=$result['st_comment']?>"></textarea>
                <br>
                <center><input type="submit" class="btn btn-primary " name="Update" value="submit" /></center>
            </form>
            <?php 
        }
        else
        {
            echo "No Record Found";
        }
    }
    else
    {
        echo "Something Went Wrong in your Form";
    }
    ?>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
