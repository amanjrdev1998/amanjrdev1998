<?php
$serverName = "phpmyadmin.gipl.inet";
$userName = "learning_user";
$password = "learning";
$dbName = "learning_test";

$conn = mysqli_connect($serverName,$userName,$password,$dbName);

if(!$conn){
	die('could not connect mysql:.mysqli_error()');
}
?>