<?php
define('CLIENT_TYPE',array(
                 '' => "Select client type",
                 '1' => "Uncertain client",
                 '2' => "Urgent client",
                 '3' => "Empathetic client",
                 '4' => "Indecisive client",
                 '5' => "Efficient client",
               ));

  define('DESIGNATION',array(
                  '' => "Select designation",
                  '1'=> "Business Man",
                  '2'=> "Teacher",
                  '3'=> "Customer Support",
               ));

  define('COUNTRY',array(
					''  =>"Select country",
  					'1' =>"INDIA",
  					'2' =>"USA",
  					'3' =>"Brazil",
  					'4' =>"Canada",
  					'5' =>"Europe",
  					));

  define('TIME_ZONE',array(
					''  =>"Select Time Zone",
  					'1' =>"[UTC + 5:30] Indian Standard Time",
  					'2' =>"[GMT-4]USA ",
  					'3' =>"[GMT-04:00] Brazil",
  					'4' =>"[GMT-08:00]Canada",
  					'5' =>"[UTC + 1] Central European Time",
  					));
   
?>