<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>client Registration Form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>
<body>
	<?php
    include "const.php";
	?>
<div class="container">
	<div class="col-md-10">
		<div class="form">

	     <span style="color:green"><?php if(isset($_SESSION['msg'])){ echo $_SESSION['msg']; unset($_SESSION['msg']);}?></span>


			<h5 id="head1">Client Register Form</h5>
			<form action ="register-process.php" method="post">
				<div class="head">
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Name :</label>
						    </div>
						    <div class="col-md-1">
								<select name="gender" class="form-control">
									<option value="">select</option>
									<option value="1">Mr.</option>
									<option value="2">Mrs.</option>
									<option value="3">Miss.</option>
								</select>
							<span class="err"><?php if(isset($_SESSION['gender'])){ echo $_SESSION['gender']; unset($_SESSION['gender']);}?></span>

							</div>
							<div class="col-md-3">
							  <input type="text" name="fname" class="form-control" placeholder="First Name">
							  <span class="err"><?php if(isset($_SESSION['fname'])){ echo $_SESSION['fname']; unset($_SESSION['fname']);}?></span>
						    </div>
						    <div class="col-md-3">
							  <input type="text" name="lname" class="form-control" placeholder="Last Name">
							  <span class="err"><?php if(isset($_SESSION['lname'])){ echo $_SESSION['lname']; unset($_SESSION['lname']);}?></span>
						    </div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Client Type :</label>
						    </div>
						    <div class="col-md-6">
								<select name="clienttype" class="form-control">
									<?php 
							          foreach(CLIENT_TYPE as $key => $value){
							        ?>
							        <option value="<?php echo $key;?>"><?php echo $value;?>
							        <?php   
							          }
							        ?>
								</select>
							<span class="err"><?php if(isset($_SESSION['clienttype'])){ echo $_SESSION['clienttype']; unset($_SESSION['clienttype']);}?></span>

							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Company Name :</label>
						    </div>
						    <div class="col-md-6">
								<input type="text" name="companyname" class="form-control" placeholder="Company Name">
								<span class="err"><?php if(isset($_SESSION['companyname'])){ echo $_SESSION['companyname']; unset($_SESSION['companyname']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Designation :</label>
						    </div>
						    <div class="col-md-6">
								<select name="designation" class="form-control">
									<?php 
							          foreach(DESIGNATION as $key => $value){
							        ?>
							        <option value="<?php echo $key;?>"><?php echo $value;?>
							        <?php   
							          }
							        ?>
								</select>
								<span class="err"><?php if(isset($_SESSION['designation'])){ echo $_SESSION['designation']; unset($_SESSION['designation']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Address :</label>
						    </div>
						    <div class="col-md-6">
								<textarea name="address" class="form-control"></textarea>
								<span class="err"><?php if(isset($_SESSION['address'])){ echo $_SESSION['address']; unset($_SESSION['address']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>City :</label>
						    </div>
						    <div class="col-md-6">
								<input type="text" name="city" class="form-control" placeholder="City Name">
								<span class="err"><?php if(isset($_SESSION['city'])){ echo $_SESSION['city']; unset($_SESSION['city']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>State :</label>
						    </div>
						    <div class="col-md-6">
								<input type="text" name="state" class="form-control" placeholder="State Name">
								<span class="err"><?php if(isset($_SESSION['state'])){ echo $_SESSION['state']; unset($_SESSION['state']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Zip code :</label>
						    </div>
						    <div class="col-md-6">
								<input type="text" name="zipcode" class="form-control" value="" placeholder="Zip code">
								<span class="err"><?php if(isset($_SESSION['zipcode'])){ echo $_SESSION['zipcode']; unset($_SESSION['zipcode']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Country :</label>
						    </div>
						    <div class="col-md-6">
								<select name="country" class="form-control">
									<?php 
							          foreach(COUNTRY as $key => $value){
							        ?>
							        <option value="<?php echo $key;?>"><?php echo $value;?>
							        <?php   
							          }
							        ?>
								</select>
								<span class="err"><?php if(isset($_SESSION['country'])){ echo $_SESSION['country']; unset($_SESSION['country']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Phone :</label>
						    </div>
						    <div class="col-md-6">
								<input type="text" name="phone" class="form-control" placeholder="Phone">
								<span class="err"><?php if(isset($_SESSION['phone'])){ echo $_SESSION['phone']; unset($_SESSION['phone']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Fax :</label>
						    </div>
						    <div class="col-md-6">
								<input type="text" name="fax" class="form-control" placeholder="Fax">
								<span class="err"><?php if(isset($_SESSION['fax'])){ echo $_SESSION['fax']; unset($_SESSION['fax']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Email :</label>
						    </div>
						    <div class="col-md-6">
								<input type="email" name="email" class="form-control" placeholder="Email">
								<span class="err"><?php if(isset($_SESSION['email'])){ echo $_SESSION['email']; unset($_SESSION['email']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Other Information :</label>
						    </div>
						    <div class="col-md-6">
								<textarea name="information" class="form-control"></textarea>
								<span class="err"><?php if(isset($_SESSION['information'])){ echo $_SESSION['information']; unset($_SESSION['information']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>chat Id :</label>
						    </div>
						    <div class="col-md-6">
								<input type="text" name="chatid" class="form-control" placeholder="Chat Id">
								<span class="err"><?php if(isset($_SESSION['chatid'])){ echo $_SESSION['chatid']; unset($_SESSION['chatid']);}?></span>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-md-3">
							  <label>Time Zone:</label>
						    </div>
						    <div class="col-md-6">
								<select name="timezone" class="form-control">
									<?php 
							          foreach(TIME_ZONE as $key => $value){
							        ?>
							        <option value="<?php echo $key;?>"><?php echo $value;?>
							        <?php   
							          }
							        ?>
								</select>
								<span class="err"><?php if(isset($_SESSION['timezone'])){ echo $_SESSION['timezone']; unset($_SESSION['timezone']);}?></span>
							</div>
						</div>
					</div>
					<button type="submit" class="btn btn-primary button">Submit</button>   
					</div>
             	</div>
			</form>
	   </div>
   </div>
</div>
</body>
</html>
