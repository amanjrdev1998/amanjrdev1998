<?php
session_start();
include "db.php";
$statusId = $_GET['Id'];
$currentStatus = $_GET['curStatus'];

if($currentStatus == 0){
 $update = "UPDATE tbl_client_register SET client_status = 1 where client_id = $statusId";
 
 $res = mysqli_query($conn,$update);	
 
}else{
  $update = "UPDATE tbl_client_register SET client_status = 0 where client_id = $statusId";
   
  $res = mysqli_query($conn,$update);	
}
$_SESSION["msg"]="Status Updated successfully!";
header("location:table.php");
mysqli_close($conn);
?>