<?php
session_start();
include "db.php";

$Id = $_GET['Id'];

$sql ="DELETE FROM `tbl_client_register` WHERE client_id =$Id";
$result = mysqli_query($conn,$sql);
if($result){
	$_SESSION['msg'] ="client Deleted SuccessFully";
         header("location:table.php");
         exit;
}else{
	echo "error";
}

?>