<!DOCTYPE html>
<html>
   <head>
      <title>client View</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   </head>
   <body>
      <div class="container" style="margin-top:5%">
         <div class="table-title">
            <div class="row">
               <div class="col-sm-5">
                  <h4>Client <b>Details</b></h4>
               </div>
            </div>
         </div>
         <table cellpadding="0" cellspacing="0" border="1" class="display table table-bordered" id="hidden-table-info">
            <?php 
               include "db.php";
               include "const.php";
               $Id = $_GET["Id"];
               $sql = "SELECT * FROM tbl_client_register WHERE client_id = $Id";
               $result = mysqli_query($conn,$sql);
               $row = mysqli_fetch_assoc($result);
               
               ?>          
            <tbody>
               <tr>
                  <th>Id :</th>
                  <td><?php echo $row["client_id"];?></td>
                  <th>Gender :</th>
                  <td><?php if($row["client_gender"]==1){
                     echo "Mr.";
                     }else if($row["client_gender"]==2){
                     echo "Mrs.";
                     }else{
                     echo "Miss.";
                     } 
                     ?></td>
               </tr>
               <tr>
                  <th>First Name :</th>
                  <td><?php echo $row["client_first_name"];?></td>
                  <th>Last Name :</th>
                  <td><?php echo $row["client_last_name"];?></td>
               </tr>
               <tr>
                  <th>Client Type :</th>
                  <td><?php echo CLIENT_TYPE[$row["client_type"]];?></td>
                  <th>Company Name :</th>
                  <td><?php echo $row["client_company_name"];?></td>
               </tr>
               <tr>
                  <th>Designation :</th>
                  <td><?php echo DESIGNATION[$row["client_designation"]];?></td>
                  <th>Address :</th>
                  <td><?php echo $row["client_address"];?></td>
               </tr>
               <tr>
                  <th>City :</th>
                  <td><?php echo $row["client_city"];?></td>
                  <th>State :</th>
                  <td><?php echo $row["client_state"];?></td>
               </tr>
               <tr>
                  <th>Zip code :</th>
                  <td><?php echo $row["client_zipcode"];?></td>
                  <th>Country :</th>
                  <td><?php echo COUNTRY[$row["client_country"]];?></td>
               </tr>
               <tr>
                  <th>Phone :</th>
                  <td><?php echo $row["client_phone"];?></td>
                  <th>Fax :</th>
                  <td><?php echo $row["client_fax"];?></td>
               </tr>
               <tr>
                  <th>Email :</th>
                  <td><?php echo $row["client_email"];?></td>
                  <th>Other Information :</th>
                  <td><?php echo $row["client_other_information"];?></td>
               </tr>
               <tr>
                  <th>chat Id :</th>
                  <td><?php echo $row["client_chat_id"];?></td>
                  <th>Time Zone :</th>
                  <td><?php echo TIME_ZONE[$row["client_time_zone"]];?></td>
               </tr>
               <tr>
                  <th>Client Status :</th>
                  <td><?php if($row["client_status"]==0){
                     echo "Inactive";
                     }else{
                     echo "Active";
                     }
                     ?></td>
                  <th>Date :</th>
                  <td><?php echo $row["client_date"];?></td>
               </tr>
            </tbody>
         </table>
      </div>
   </body>
   </body>
</html>