<?php
session_start();
include 'db.php';

function test_input($data){
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
$flag = True;

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$Id = $_POST["update_id"];

	if(empty($_POST["gender"])){

		$_SESSION["gender"] = "Gender is Required";	
		$flag = false;

	}else{
		$gender   = test_input($_POST["gender"] ? $_POST["gender"] : "");
	}
	if(empty($_POST["fname"])){

		$_SESSION["fname"] = "First Name is Required";
		$flag = false;
		
	}else{
		$fName   = test_input($_POST["fname"] ? $_POST["fname"]  : "");
	}
	if(empty($_POST["lname"])){

		$_SESSION["lname"] = "Last Name is Required";
		$flag = false;

	}else{
		$lName    = test_input($_POST["lname"] ? $_POST["lname"]  : "");
	}
	
	if(empty($_POST["clienttype"])){

		$_SESSION["clienttype"] = "Client Type is Required";
		$flag = false;

	}else{
		$clientType  = test_input($_POST["clienttype"] ? $_POST["clienttype"] : "");
	}
	if(empty($_POST["companyname"])){

		$_SESSION["companyname"] = "Company Name is Required";
		$flag = false;
		
	}else{
		$companyName = test_input($_POST["companyname"] ? $_POST["companyname"] : "");
	}
	if(empty($_POST["designation"])){

		$_SESSION["designation"] = "Designation is Required";
		$flag = false;
		
	}else{
		$designation = test_input($_POST["designation"] ? $_POST["designation"] : "");
	}
	if(empty($_POST["address"])){

		$_SESSION["address"] = "Address is Required";
		$flag = false;

	}else{
		$address   = test_input($_POST["address"] ? $_POST["address"] : "");
	}
	if(empty($_POST["city"])){

		$_SESSION["city"] = "City is Required";
		$flag = false;

	}else{
		$city     = test_input($_POST["city"] ? $_POST["city"] : "");
	}
	if(empty($_POST["state"])){

		$_SESSION["state"] = "State is Required";
		$flag = false;
		
	}else{
		$state    = test_input($_POST["state"] ? $_POST["state"] : "");
	}
	if(empty($_POST["zipcode"])){

		$_SESSION["zipcode"] = "Zip code is Required";
		$flag = false;

	}else{
		$zipcode   = test_input($_POST["zipcode"] ? $_POST["zipcode"] : "");
	}
	if(empty($_POST["country"])){

		$_SESSION["country"] = "Country is Required";
		$flag = false;

	}else{
		$country   = test_input($_POST["country"] ? $_POST["country"] : "");
	}
	if(empty($_POST["phone"])){

		$_SESSION["phone"] = "Phone is Required";
		$flag = false;

	}else{
		$phone    = test_input($_POST["phone"] ? $_POST["phone"] : "");
	}
	if(empty($_POST["fax"])){

		$_SESSION["fax"] = "Fax is Required";
		$flag = false;

	}else{
		$fax    = test_input($_POST["fax"] ? $_POST["fax"] : "");
	}
	if(empty($_POST["email"])){

		$_SESSION["email"] = "Email is Required";
		$flag = false;
		
	}else{
		$email  = test_input($_POST["email"] ? $_POST["email"] : "");
	}
	if(empty($_POST["information"])){

		$_SESSION["information"] = "Information is Required";
		$flag = false;
		
	}else{
		$information = test_input($_POST["information"] ? $_POST["information"] : "");
	}
	if(empty($_POST["chatid"])){

		$_SESSION["chatid"] = "chatId is Required";
		$flag = false;
		
	}else{
		$chatId  = test_input($_POST["chatid"] ? $_POST["chatid"] : "");
	}
	if(empty($_POST["timezone"])){

		$_SESSION["timezone"] = "Timezone is Required";
		$flag = false;

	}else{
		$timezone  = test_input($_POST["timezone"] ? $_POST["timezone"] : "");
	}	
}
if($flag){
$updatequery = "UPDATE `tbl_client_register` SET client_first_name ='$fName', client_last_name ='$lName', client_gender ='$gender',client_type ='$clientType', client_company_name ='$companyName', client_designation ='$designation', client_address ='$address', client_city ='$city', client_state ='$state', client_zipcode ='$zipcode', client_country ='$country', client_phone ='$phone', client_fax ='$fax', client_email ='$email', client_other_information ='$information', client_chat_id ='$chatId', client_time_zone ='$timezone'  WHERE client_id = $Id";
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
$result =mysqli_query($conn,$updatequery);
if($result){
	
	$_SESSION["msg"]="form Updated successfully!";
	header("location:table.php");
	exit;
}
else{
  $_SESSION["msg"]="Somthing Went Wrong!";
	header("location:update.php");
	exit;
}
}else{
	$_SESSION["msg"]="Not Empty Any Field!";
	header("location:update.php?Id=$Id");
	exit;
}
mysqli_close($conn);
?>
