-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2022 at 10:45 AM
-- Server version: 10.1.44-MariaDB-1~xenial
-- PHP Version: 7.0.33-0ubuntu0.16.04.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learning_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_client_register`
--

CREATE TABLE `tbl_client_register` (
  `client_id` int(11) NOT NULL,
  `client_first_name` varchar(100) DEFAULT NULL,
  `client_last_name` varchar(100) DEFAULT NULL,
  `client_gender` tinyint(2) DEFAULT NULL COMMENT '1-Mr;2-Mrs;3-Miss',
  `client_type` int(6) DEFAULT NULL,
  `client_company_name` varchar(200) DEFAULT NULL,
  `client_designation` int(6) DEFAULT NULL,
  `client_address` varchar(255) DEFAULT NULL,
  `client_city` varchar(100) DEFAULT NULL,
  `client_state` varchar(100) DEFAULT NULL,
  `client_zipcode` varchar(50) DEFAULT NULL,
  `client_country` int(6) DEFAULT NULL,
  `client_phone` varchar(15) DEFAULT NULL,
  `client_fax` varchar(100) DEFAULT NULL,
  `client_email` varchar(255) DEFAULT NULL,
  `client_other_information` varchar(255) DEFAULT NULL,
  `client_chat_id` varchar(50) DEFAULT NULL,
  `client_time_zone` int(6) DEFAULT NULL,
  `client_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0-Inactive; 1-Active',
  `client_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_client_register`
--

INSERT INTO `tbl_client_register` (`client_id`, `client_first_name`, `client_last_name`, `client_gender`, `client_type`, `client_company_name`, `client_designation`, `client_address`, `client_city`, `client_state`, `client_zipcode`, `client_country`, `client_phone`, `client_fax`, `client_email`, `client_other_information`, `client_chat_id`, `client_time_zone`, `client_status`, `client_date`) VALUES
(3, 'test', 'test1', 1, 1, 'testttt', 2, 'Vill - Thakurahat, Post-sabar, Dist-Kaimur Bhabua', 'Bhabua', 'Bihar', '821104', 1, '08227830011', 'abc78541', 'pinki@gmail.com', 'trh', 'pr87451248', 5, 1, '2022-06-10 16:25:28'),
(6, 'pinki', 'pandey', 0, 2, 'Fulestop', 1, 'Vill - Thakurahat, Post-sabar, Dist-Kaimur Bhabua', 'Bhabua', 'Bihar', '821104', 1, '08227830011', 'abc78541', 'pinki@gmail.com', 'ytd', 'gtfrh', 4, 1, '2022-06-10 18:44:23'),
(9, 'pinki', 'pandey', 1, 1, 'Fulestop', 1, 'Vill - Thakurahat, Post-sabar, Dist-Kaimur Bhabua', 'Bhabua', 'Bihar', '821104', 1, '08227830011', 'abc78541', 'pinki@gmail.com', 'rttttttttth', 'thr', 5, 0, '2022-06-11 11:15:19'),
(11, 'pinki', 'pandey', 3, 1, 'Fulestop', 1, 'Vill - Thakurahat, Post-sabar, Dist-Kaimur Bhabua', 'Bhabua', 'Bihar', '821104', 1, '08227830011', 'abc78541', 'pinki@gmail.com', 'rg', 'thr', 2, 1, '2022-06-13 10:10:23'),
(12, 'tfhrtbh1', 'Kumarfsdf sdfsdfsd', 1, 3, 'fsdfsdfsdfs', 3, 'dfsdfsdf', 'sdfsdf', 'sdfsd', 'sdfsd', 2, 'sdfsdf', 'sdfds', 'sdfsdfdfsdf@dfasd.com', 'sdfsd', 'dfsd', 5, 1, '2022-06-13 10:30:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_client_register`
--
ALTER TABLE `tbl_client_register`
  ADD PRIMARY KEY (`client_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_client_register`
--
ALTER TABLE `tbl_client_register`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
