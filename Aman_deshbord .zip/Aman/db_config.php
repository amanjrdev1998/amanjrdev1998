<?php 
class db_dash{

    public $conn;  
    
    public function __construct()  
    {   
        $host='phpmyadmin.gipl.inet';
        $username='learning_user';   
        $pass='learning';
        $Name = "learning_test";

    $conn= mysqli_connect($host,$username,$pass,$Name); 
				$this->conn= $conn;


				if(mysqli_connect_error())
				{
					echo "oops! Your Database Conection Fail:", mysqli_connect_error();
				}
        }
		public function data($abc)
		{
			$return = mysqli_real_escape_string($this->conn,$abc);
			return $return;
		}

    public function dash_insert($meeting_name ,$meeting_date ,$nm_facilitor ,$time1 ,$time2 ,$ch1,$ch2 ,$meeting_venu ,$attendees ,$non_attendees ,$agenda_discss ,$disicion ,$step_taken ,$relation_behind ,$perd, $filename ,$review)
    {
    $dash_insert ="INSERT INTO `dashboard_task`(meeting_name, meeting_date, nm_facilitor, time1, time2, ch1, ch2, meeting_venu, attendees, non_attendees, agenda_discss, disicion, step_taken, relation_behind, perd, myfile, review) 
    VALUE ('$meeting_name' ,'$meeting_date' ,'$nm_facilitor' ,'$time1' ,'$time2' ,'$ch1','$ch2' , '$meeting_venu','$attendees' ,'$non_attendees' ,'$agenda_discss' ,'$disicion','$step_taken' ,'$relation_behind' , '$perd', '$filename' ,'$review')";

    $check = mysqli_query($this->conn, $dash_insert);	
        if($check)
        {
            return true;
        }
        else
        {
            return false;
        }
} 

        // Get all Data 
        public function dash_get(){
            $get_dash = "SELECT * FROM `dashboard_task`";
            $sql = mysqli_query($this->conn,$get_dash);
            return $sql;
        }

        // public function read($id)
        // {
        //     $sql = "SELECT * FROM dashboard_task";
        //     if($id)
        //             { $sql .= " WHERE id= $id";}
        //     $result = mysqli_query($this->conn,$sql);
        //     return $result;
        // }

            //Delete Record 
            public function dash_delete($id){
                $delt_sql ="DELETE FROM `dashboard_task` WHERE id =$id";
                $del = mysqli_query($this->conn, $delt_sql);
                
                if($del){
                    return true;
    
                }else{
                    return false;
                }
                
            }

            //Select Querry for Update query 
            public function edit_select($id)
            {
                $id = mysqli_real_escape_string($this->conn, $id);
                $dash_sql ="SELECT * FROM dashboard_task WHERE id='$id' LIMIT 1";
                $result= $this->conn->query($dash_sql);
                if($result->num_rows == 1){
                    $data = $result->fetch_assoc();
                    //print_r($data);

                    return $data;
                }else{
                    return false;
                }
            }

		 //Update Dash Data 
	public function dash_update($checkdata,$id)
    {	

            $id = mysqli_real_escape_string($this->conn,$id);
            $meeting_name = $checkdata['meeting_name'];
            
            $meeting_date = $checkdata['meeting_date'];
            
            $nm_facilitor = $checkdata['nm_facilitor'];

            $time1 = $checkdata['time1'];
        
            $time2 = $checkdata['time2'];

            $ch1 = $checkdata['ch1'];

            $ch2 = $checkdata['ch2'];
        
            $meeting_venu = $checkdata['meeting_venu'];
        
            $attendees = $checkdata['attendees'];
        
            $non_attendees =$checkdata['non_attendees'];
        
            $agenda_discss = $checkdata['agenda_discss'];

            $disicion = $checkdata['disicion'];

            $step_taken = $checkdata['step_taken'];

            $relation_behind = $checkdata['relation_behind'];

            $perd = $checkdata['perd'];

            $review = $checkdata['review'];

            $oldimage = $_POST["oldimage"];

            $filename = $_FILES["image"]["name"];
        

        if($filename != "")
        {   

                    $file_ext=strtolower(end(explode('.',$filename)));
			        $extensions= array("jpeg","jpg","png");
			      
			      if(in_array($file_ext,$extensions)=== false){

			         echo "please choose a JPG || JPEG and PNG file.";
                   
			        }else{
                     $ab = move_uploaded_file($_FILES["image"]["tmp_name"],'images/'.$filename);
                    }
        }else{           
            $filename=$oldimage;
        }

    $upd_dash= "UPDATE `dashboard_task` SET meeting_name = '$meeting_name', meeting_date= '$meeting_date' 
    , nm_facilitor='$nm_facilitor',time1='$time1' , time2='$time2' ,ch1= '$ch1' , ch2= '$ch2' ,meeting_venu='$meeting_venu'
    ,attendees='$attendees',non_attendees='$non_attendees', agenda_discss='$agenda_discss',
    disicion='$disicion',step_taken='$step_taken',relation_behind='$relation_behind',
    perd='$perd',review='$review' , myfile = '$filename' WHERE id='$id'";   

        $result = $this->conn->query($upd_dash);
            if($result)
            {
            return true;
        }
            else
            {
            return false;
        }
    }
    
    // public function search_data(){
     

    // $search_data ="SELECT * FROM dashboard_task WHERE LIKE meeting_name like '%$srh%' ";
    // // $result_srh= $this->conn->querry($search_data);
    // // $results = $srh->fetchAll();
    // // $results = $search_data->fetchAll();
    // }
}
 $db_object = new db_dash();
?>