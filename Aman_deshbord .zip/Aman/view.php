<?php 
include('db_config.php');
// $sql = $db_object->dash_get();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>

<?php 
    if(isset($_GET['id']))
    {
        $id = mysqli_real_escape_string($db_object->conn,$_GET['id']);
        $result = $db_object->edit_select($id);
    //print_r($result['attendees']);
    if($result)
    {


?>

    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="mt-5 mb-3">View Record</h1>
                        

        <div class="form-group">
            <label>Meeting name:</label>
            <p><b><?php echo $result['meeting_name'] ?></b></p>
        </div>
        <div class="form-group">
            <label>Meeting Date :</label>
            <p><b><?php echo $result['meeting_date'] ?></b></p>
        </div>

        <div class="form-group">
            <label>NAME OF FACILITATOR :</label>
            <p><b><?php echo $result['nm_facilitor'] ?></b></p>
        </div>
        <div class="form-group">
            <label>TIME- 1:</label>
            <p><b><?php echo $result['time1'] ?></b></p>
        </div>
        <div class="form-group">
            <label>TIME- 2:</label>
            <p><b><?php echo $result['time2'] ?></b></p>
        </div>

        <div class="form-group">
            <label>MEETING TYPE -1 :</label>
            <p><b><?php echo $result['ch1'] ?></b></p>
        </div>
        <div class="form-group">
            <label>MEETING TYPE -2 :</label>
            <p><b><?php echo $result['ch2'] ?></b></p>
        </div>
        <div class="form-group">
            <label>MEETING VENUE :</label>
            <p><b><?php echo $result['meeting_venu'] ?></b></p>
        </div>
        
        <div class="form-group">
            <label>AGENDA & DISCUSSION :</label>
            <p><b><?php echo $result['agenda_discss'] ?></b></p>
        </div>
        <div class="form-group">
            <label>DECISION :</label>
            <p><b><?php echo $result['disicion'] ?></b></p>
        </div>

        <div class="form-group">
            <label>STEP TO BE TAKEN :</label>
            <p><b><?php echo $result['step_taken'] ?></b></p>
        </div>
        <div class="form-group">
            <label>RATIONAL BEHIND THE DECISION :</label>
            <p><b><?php echo $result['relation_behind'] ?></b></p>
        </div>
        <div class="form-group">
            <label>PREPARED BY-2 :</label>
            <p><b><?php echo $result['perd'] ?></b></p>
        </div>
        <div class="form-group">
            <label>REIEWED BY:</label>
            <p><b><?php echo $result['review'] ?></b></p>
        </div>


        <p><a href="get.php" class="btn btn-primary">Dashboard</a></p>
                </div>
            </div>        
        </div>
    </div>

    <?php 
        }
        else
        {
            echo "No Record Found  In Databsse ";
        }
    }
    else
    {
        echo "Something Wrong in Your form ";
    }
    ?>

</body>

</html>