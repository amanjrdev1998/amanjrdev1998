<?php
require 'db_config.php';
$sql = $db_object->dash_get();
// $result_search = $db_object->search_data();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GET DATA OF DASH-BOARD DATA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
</head>
<style>
  #search{
    float:right ;
  }

</style>
<body>


 <!-- <a href="index.php" target="_blank" class="btn-primmary" style="float: right;">Add New Detail</a> -->
<table cellpadding="0" cellspacing="0" class="display table table-bordered" id="hidden-table-info" >
<tbody>
    <tr>
        <th>DASHBOARD ID</th>
        <th>MEETING NAME</th>
        <th>MEETING DATE</th>
        <!-- <th>NAME OF THE FACILITATOR</th> --> 
        <th>TIME- 1</th>
        <th>TIME-2</th>
        <th>MEETING TYPE -1</th>
        <th>MEETING TYPE -2</th>
        <th>MEETING VENUE</th>
        <th>ATTENDEES</th>
        <th>NON-ATTENDEES</th>
        <!-- <th>AGENDA & DISCUSSION </th> -->
        <th>DECISION</th>
        <th>STEP TO BE TAKEN </th>
        <th>RATIONAL BEHIND THE DECISION</th> 
         <th>PREPARED BY-1</th>
        <!--<th>PREPARED BY-2</th>-->
        <th>FILE</th>
        <th>REIEWED BY</th>
        <th>ACTION</th>
    </tr> 

  
  <?php 
  while ($row= mysqli_fetch_assoc($sql)){
  ?>

  <tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['meeting_name']?></td>
    <td><?php echo $row['meeting_date'];?></td>
    <td><?php echo $row['time1'];?></td>
    <td><?php echo $row['time2'];?></td>
    <td><?php echo $row['ch1'];?></td>
    <td><?php echo $row['ch2'];?></td>
    <td><?php echo $row['meeting_venu'];?></td>
    <td><?php echo $row['attendees'];?></td>
    <td><?php echo $row['non_attendees'];?></td>
    <td><?php echo $row['disicion'];?></td>
    <td><?php echo $row['step_taken'];?></td>
    <td><?php echo $row['relation_behind'];?></td>
    <td><?php echo $row['perd'];?></td>
    <td><?php echo $row['myfile'];?></td>
    <td><?php echo $row['review'];?></td>
    
    <td>
      <a href="view.php?id=<?php echo $row['id'];?> " target="_blank">View</a> 
      <a href="update.php?id=<?php echo $row['id']; ?>" target="_blank">Update</a><br>
      <a href="delete.php?id=<?php echo $row['id']; ?>" target="_blank">Delete</a><br>
               
    </td>
  </tr>
<?php 
  }
?>




    </tbody>
</table>

<form action="get.php" method="post" name="" >
	<table>
		<tr>
      <a href="index.php" target="_blank" class="btn-primmary" style="float: right;">Add New Detail</a>
			<td><input type="text" name="srh"  placeholder="Enter your search keywords" /></td>
			<td><input type="submit" name="srh_btn" value="Search"/></td>
		</tr>
	</table>
 </form>


<?php 

$host='phpmyadmin.gipl.inet';
$username='learning_user';   
$pass='learning';
$Name = "learning_test";


$mysqli=mysqli_connect($host,$username,$pass,$Name);
if($mysqli === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
}



// echo $host."</br>";
// echo $username."</br>";
// echo $pass."</br>";
// echo $Name."</br>";


if(count($_POST)>0) {
  $srh = $_POST['srh'];

  // echo "$srh";

  $sql = mysqli_query($mysqli, "SELECT * FROM dashboard_task WHERE meeting_name LIKE '%$srh%'");
}
  // return $sql;

  // echo"$sql";

  // echo "<pre>";
  // print_r($sql);
  // echo "</pre>";
  // die();


 echo "<table width='1530' cellpadding='0' cellspacing='0' border='2' align='center'>";
 echo "<tr>
        <th bgcolor='#99FFCC'>Id</th>
        <th bgcolor='#99FFCC'>Meeting Name</th>
        <th bgcolor='#99FFCC'>Agenda & Discss</th>
        <th bgcolor='#99FFCC'>Time 1</th>
        <th bgcolor='#99FFCC'>Time 2</th>
        <th bgcolor='#99FFCC'>Review</th>
  </tr>";

 while ($r = mysqli_fetch_array($sql)){
  echo "<tr>";
    echo '<td>'.$r['id'].'</td>';
    echo '<td>'.$r['meeting_name'].'</td>';
    echo '<td>'.$r['agenda_discss'].'</td>';
    echo '<td>'.$r['time1'].'</td>';
    echo '<td>'.$r['time2'].'</td>';
    echo '<td>'.$r['review'].'</td>';
    echo "</tr>";
 }
 echo "</tabel>";
 ?>

</body>
</html>
