-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 04, 2022 at 10:10 AM
-- Server version: 10.1.44-MariaDB-1~xenial
-- PHP Version: 7.0.33-0ubuntu0.16.04.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learning_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_task`
--

CREATE TABLE `dashboard_task` (
  `id` int(11) NOT NULL,
  `meeting_name` varchar(200) NOT NULL,
  `meeting_date` varchar(200) NOT NULL,
  `nm_facilitor` varchar(200) NOT NULL,
  `time1` varchar(200) NOT NULL,
  `time2` varchar(200) NOT NULL,
  `ch1` varchar(200) NOT NULL,
  `ch2` varchar(200) NOT NULL,
  `meeting_venu` text NOT NULL,
  `attendees` varchar(200) NOT NULL,
  `non_attendees` varchar(200) NOT NULL,
  `agenda_discss` varchar(200) NOT NULL,
  `disicion` varchar(200) NOT NULL,
  `step_taken` varchar(20) NOT NULL,
  `relation_behind` varchar(200) NOT NULL,
  `perd` varchar(20) NOT NULL,
  `myfile` varchar(200) NOT NULL,
  `review` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dashboard_task`
--

INSERT INTO `dashboard_task` (`id`, `meeting_name`, `meeting_date`, `nm_facilitor`, `time1`, `time2`, `ch1`, `ch2`, `meeting_venu`, `attendees`, `non_attendees`, `agenda_discss`, `disicion`, `step_taken`, `relation_behind`, `perd`, `myfile`, `review`) VALUES
(6, 'hello  aman', '2022-07-14', 'abc', '18:58', '19:58', 'Sales Kick Off Meeting', 'Project Discussion', 'ddada', '["2","4"]', '["3","4"]', 'asdads', 'dasdd', 'dadada', 'adsada', 'Vikas_Jain', 'tty.png', 'Vikas_Jain'),
(7, 'Web Call', '2022-06-30', 'acf', '21:03', '20:04', '', 'Project Discussion', 'hello ', '["2","3"]', '["3","4"]', 'hello aman welcome to all work ', 'hello ', 'welcome to jaipur ', 'Welcome ', 'Vikas_Jain', 'screenshot.png', 'Vikas_Jain'),
(8, 'work ', '2022-07-07', 'bvd', '21:41', '22:44', 'Sales Kick Off Meeting ', '', 'aada', '["2","4"]', '["1","3"]', 'adad dada  sa ad dsa da sa ', 'Hello to work work ', 'work work to zone ', 'work to zone ', 'Vijay_Arora', 'screenshot.png', 'Vikas_Jain'),
(9, 'work ', '2022-07-07', 'bvd', '21:41', '22:44', 'Sales Kick Off Meeting ', '', 'aada', '["2","4"]', '["1","3"]', 'adad dada  sa ad dsa da sa ', 'Hello to work work ', 'work work to zone ', 'work to zone ', 'Vijay_Arora', 'screenshot.png', 'Vikas_Jain');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dashboard_task`
--
ALTER TABLE `dashboard_task`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dashboard_task`
--
ALTER TABLE `dashboard_task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
