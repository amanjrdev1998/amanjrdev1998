<?php 
  	require 'db_config.php';
	 $id = $_GET['id'];

	$result = $db_object->dash_delete($id);
		
	if($result)
			{
			echo "Dashboard Data Delete Success";
			header('location:get.php');
		}
			else
			{
			echo "OOPs! DATA NOT DELETE";
		}
?>

