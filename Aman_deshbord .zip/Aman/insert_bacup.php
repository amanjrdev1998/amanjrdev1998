<?php 
include 'db_config.php';
$db_object = new db_dash();

$validationflag = True;

  if(isset($_POST['submit']))
  {   
    //meeting name 
    if(!empty($_POST['meeting_name']))
    {
      $meeting_name = $db_object->data($_POST['meeting_name']);
      $msg_meeting_name=null;
    }
    else{

      $meeting_name = null;
      $msg_meeting_name = "Enter  Your meeting name";
    }

    // meeting_date 
    if(!empty($_POST['meeting_date']))
    {
      $meeting_date = $db_object->data($_POST['meeting_date']);
      $msg_meeting_date=null;
    }
    else{
      
      $meeting_date = null;
      $msg_meeting_date = "Enter Your meeting Date";
    }

    //nm_facilitor
    if(!empty($_POST['nm_facilitor']))
    {
      $nm_facilitor = $_POST['nm_facilitor'];
      $msg_nm_facilitor=null;
    }
    else{

      $nm_facilitor = null;
      $msg_nm_facilitor = "Select Name of Facilitator";
    }

    //time1
    if(!empty($_POST['time1']))
    {
      $time1 = $_POST['time1'];
      $msg_time1=null;
    }
    else{

      $time1 = null;
      $msg_time1 = "Enter Your Time 1";
    }

    //time2
    if(!empty($_POST['time2']))
    {
      $time2 = $_POST['time2'];
      $msg_time2=null;
    }
    else{

      $time2 = null;
      $msg_time2 = "Enter Your Time 2";
    }

    //ch2
    if(!empty($_POST['ch1']))
    {
      $ch1 = $_POST['ch1'];
      $msg_ch1=null;
    }
    else{

      $ch1 = null;
      $msg_ch1 = "Enter Your meeting Type";
    }

    //ch2 
    if(!empty($_POST['ch2']))
    {
      $ch2 = $_POST['ch2'];
      $msg_ch2=null;
    }
    else{

      $ch2 = null;
      $msg_ch2 = "Enter Your meeting Type";
    }

    //meeting_venu
    if(!empty($_POST['meeting_venu']))
    {
      $meeting_venu = $_POST['meeting_venu'];
      $msg_meeting_venu=null;
    }
    else{
      $meeting_venu = null;
      $msg_meeting_venu = "Enter Your meeting Venu";
    }

    //meeting_date
    if(!empty ($_POST['meeting_date']))
    {
      $attendees = json_encode($_POST['attendees']);
      $msg_attendees=null;
    }
    else{

      $attendees = null;
      $msg_attendees = "Select attendees";
    }

    //non_attendees
    if(!empty($_POST['non_attendees']))
    {
      $non_attendees = json_encode($_POST['non_attendees']);
      $msg_non_attendees=null;
    }
    else{

      $non_attendees = null;
      $msg_non_attendees = "Select non-attendees";;
    }

    $agenda_discss = $_POST['agenda_discss'];

    //disicion
    if(!empty($_POST['disicion']))
    {
      $disicion = $_POST['disicion'];
      $msg_disicion=null;
    }
    else
    {
      $disicion = null;
      $msg_disicion = "Enter Your disicion text";
    }

    // step_taken 
    if(!empty($_POST['step_taken']))
    {
      $step_taken = $_POST['step_taken'];
      $msg_step_taken=null;
    }
    else{

      $step_taken = null;
      $msg_step_taken = "Enter Your step taken text";
    }

    //relation_behind 
    if(!empty($_POST['relation_behind']))
    {
      $relation_behind = $_POST['relation_behind'];
      $msg_relation_behind=null;
    }
    else{

      $relation_behind = null;
      $msg_relation_behind = "Enter Your relation behind";
    }
    
    //perd
    if(!empty($_POST['perd']))
    {
      $perd = $_POST['perd'];
      $msg_perd=null;
    }
    else{
      $perd = null;
      $msg_perd = "Choose any One Radio Button";
    }

    //review  
    if(!empty($_POST['review']))
    {
      $review = $_POST['review'];
      $msg_review=null;
    }
    else{
      $review = null;
      $msg_review = "Enter Your review";
    }

    if(!empty($_FILES['image']))
    {
    $filename = $_FILES['image'];
    $msg_image_name=null;
    }
    else
    {
    $filename = null;
    $msg_image_name = "Choose Image From Your PC";
    }

      $filename = $_FILES['image']['name'];
      $imageFileType = strtolower(pathinfo($filename,PATHINFO_EXTENSION));
      $extensions_arr = array("jpg","jpeg","png","gif");

    // if($extensions_arr == false ){
    //   echo "Your Image is Not Match";
    //   }
    //   else
    //   {}
   
  if(move_uploaded_file($_FILES["image"]["tmp_name"], 'img/'.$filename))
  {
    // if(!empty($meeting_name) && !empty($meeting_date) && !empty($nm_facilitor) && !empty($time1) 
    //   && !empty($time2) && !empty($ch1) && !empty($ch2) && !empty($meeting_venu) && !empty($attendees) 
    //   && !empty($non_attendees) && !empty($disicion) && !empty($step_taken) 
    //   && !empty($relation_behind) && !empty($perd) && in_array($imageFileType,$extensions_arr) && !empty($review))
    // {
  if($validationflag)
{
  $check = $db_object->dash_insert($meeting_name ,$meeting_date ,$nm_facilitor ,$time1 ,$time2 ,$ch1,$ch2 ,$meeting_venu ,$attendees ,$non_attendees ,$agenda_discss ,$disicion ,$step_taken ,$relation_behind ,$perd, $filename ,$review ); 
    if($check)
        {
            echo "Your data Is Sucessfully Inserted";
            // header('location:get.php');
        }
        else
        {
            echo "OOP! Your Data Not Inserted!".mysqli_connect_error($check1);
        }
}
else{
      echo "Your Data Is Not Submited ";
    }
  }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>

<form action="" method="POST" enctype="multipart/form-data">

    Name Of Meeting*: <input type="text" name="meeting_name" id="meeting_name" value='<?php if(!empty($meeting_name)) echo  $meeting_name; ?>'><br>
                <?php 
                if(!empty($msg_meeting_name)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_meeting_name .'</h2>';
                endif; 
                ?>  


    Meeting Date*   : <input type="date" id="meeting_date" name="meeting_date" value='<?php if(!empty($meeting_date)) echo  $meeting_date; ?>'><br>

                <?php           
                if(!empty($msg_meeting_date)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_meeting_date .'</h2>';
                endif; 
                ?>

    Name Of the Facilitator* :<select name="nm_facilitor" id="nm_facilitor"><br>
                                <option selected value=" ">Select Facilitator Name</option>
                                <option value="abc" <?php if(!empty($nm_facilitor) && ($nm_facilitor == "abc")) echo "SELECTED";?>>abc</option>
                                <option value="bvd" <?php if(!empty($nm_facilitor) && ($nm_facilitor == "bvd")) echo "SELECTED";?>>bvd</option>
                                <option value="acf" <?php if(!empty($nm_facilitor) && ($nm_facilitor == "acf")) echo "SELECTED";?>>acf</option>
                                <option value="acf" <?php if(!empty($nm_facilitor) && ($nm_facilitor == "afd")) echo "SELECTED";?>>afd</option>
                            </select><br>
                <?php 
                if(!empty($msg_nm_facilitor)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_nm_facilitor .'</h2>';
                endif; 
                ?>  

    Meeting Time  : <input type="time" id="time1" name="time1" value='<?php if(!empty($time1)) echo  $time1;?>'>

                <?php   
                if(!empty($msg_time1)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_time1 .'</h2>';
                endif; 
                ?> 

                    <input type="time" id="time2" name="time2" value='<?php if(!empty($time1)) echo  $time1;?>'><br>

                    <?php           
                if(!empty($msg_time2)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_time2 .'</h2>';
                endif; 
                ?>




    Meeting type  : <input type="checkbox" id="ch1" name="ch1" value='Sales Kick Off Meeting <?php if(!empty($ch1)) echo  $ch1; ?>'>Sales Kick Off Meeting 
                <?php           
                if(!empty($msg_ch1)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_ch1 .'</h2>';
                endif; 
                ?>

                <input type="checkbox" id="ch2" name="ch2" value='Project Discussion <?php if(!empty($ch1)) echo  $ch1; ?>'>Project Discussion <br>

                <?php           
                if(!empty($msg_ch2)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_ch2.'</h2>';
                endif; 
                ?>



    Meeting Venue*: <input type="text" name="meeting_venu" id="meeting_venu" value='<?php if(!empty($meeting_venu)) echo  $meeting_venu;?>'><br>
                <?php           
                if(!empty($msg_meeting_venu)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_meeting_venu.'</h2>';
                endif; 
                ?>



    Attendees*  : <select name="attendees[]" id="attendees" multiple size = 4 ><br>
                        <option value="1" <?php if(!empty($attendees) && ($attendees == "1")) echo "SELECTED";?>>Adarsh Kumar</option>
                        <option value="2" <?php if(!empty($attendees) && ($attendees == "2")) echo "SELECTED";?>>Abhishek Rawat</option>
                        <option value="3" <?php if(!empty($attendees) && ($attendees == "3")) echo "SELECTED";?>>Anamika Jain</option>
                        <option value="4" <?php if(!empty($attendees) && ($attendees == "4")) echo "SELECTED";?>>Anant Chouhan</option>
                    </select><br>

                    <?php           
                if(!empty($msg_attendees)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_attendees.'</h2>';
                endif; 
                ?>



    Non-Attendees*: <select name="non_attendees[]" id="non_attendees" multiple size = 4><br>
                        <option value="1" <?php if(!empty($non_attendees) && ($non_attendees == "1")) echo "SELECTED";?> >Adarsh Kumar</option>
                        <option value="2" <?php if(!empty($non_attendees) && ($non_attendees == "1")) echo "SELECTED";?> >Abhishek Rawat</option>
                        <option value="3" <?php if(!empty($non_attendees) && ($non_attendees == "1")) echo "SELECTED";?> >Anamika Jain</option>
                        <option value="4" <?php if(!empty($non_attendees) && ($non_attendees == "1")) echo "SELECTED";?> >Anant Chouhan</option>
                    </select><br>

                    <?php           
                if(!empty($msg_non_attendees)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_non_attendees.'</h2>';
                endif; 
                ?>



    Agenda & Discussion: <textarea name="agenda_discss" id="" cols="20" rows="5"></textarea><br>

    Decision Taken* : 
                    Decision: <textarea name="disicion" id="disicion" cols="20" rows="5" value='<?php if(!empty($disicion)) echo  $disicion; ?>'></textarea>

                    <?php           
                if(!empty($msg_disicion)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_disicion.'</h2>';
                endif; 
                ?>

                    Step To be taken : <textarea name="step_taken" id="step_taken" cols="20" rows="5" value='<?php if(!empty($disicion)) echo  $disicion; ?>'></textarea>

                    <?php           
                if(!empty($msg_step_taken)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_step_taken.'</h2>';
                endif; 
                ?>


                    Rationale Behind the Decision: <textarea name="relation_behind" id="" cols="20" rows="5" value='<?php if(!empty($relation_behind)) echo  $relation_behind; ?>'></textarea><br>

                <?php           
                if(!empty($msg_relation_behind)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_relation_behind.'</h2>';
                endif; 
                ?>

    Prepared By* : Vijay Arora :<input type="radio" id="perd" name="perd" value="Vijay_Arora"value="male"<?php if ((!isset($_POST['perd'])) || ((isset
                  ($_POST['perd'])) == 0)) {echo 'checked="checked"';}; ?>>
                   Vikas Jain :<input type="radio" id="perd" name="perd" value="Vikas_Jain"<?php if ((!isset($_POST['perd'])) || ((isset
                  ($_POST['perd'])) == 1)) {echo 'checked="checked"';}; ?> /> <br>

                <?php           
                if(!empty($msg_perd)):
                    echo "<h2 class='alert alert-danger' role='alert'>". $msg_perd.'</h2>';
                endif; 
                ?>


    
        File  * : <input type="file" id="image" name="image"><br>


    Reviewed By*     :  <select name="review" id="review" ><br>
                        <option value="Vijay_Arora"<?php if(!empty($review) && ($review == "Vijay_Arora")) echo "SELECTED";?>>Vijay Arora</option>
                        <option value="Vikas_Jain" <?php if(!empty($review) && ($review == "Vikas_Jain")) echo "SELECTED";?>>Vikas Jain</option>
                        </select>
                        <?php         
                        if(!empty($msg_review)):
                            echo "<h2 class='alert alert-danger' role='alert'>". $msg_review.'</h2>';
                        endif; 
                        ?>

                        
                        <br>
    <input type="submit" value="Save" name="submit">
</form>

<a href="get.php" class="btn-success" >View Data</a>

</body>
</html>