<?php 
include('db_config.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UPDATE DASHBOARD DATA</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>

<?php 

        if(isset($_GET['id']))
        {
            $id = mysqli_real_escape_string($db_object->conn,$_GET['id']);
            $result = $db_object->edit_select($id);
        //print_r($result['attendees']);
        if($result)
        {

    ?>

<form action="dash_updt.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?=$result['id']?>">
    Name Of Meeting*:<input type="text" name="meeting_name" id="meeting_name" value="<?php echo $result['meeting_name'] ?>"><br>
    Meeting Date*   :<input type="date" id="meeting_date" name="meeting_date" value="<?php echo $result['meeting_date'] ?>"><br>
    Name Of the Facilitator* :<select name="nm_facilitor" id="nm_facilitor"><br>
                            
    <option selected value=" ">Select Facilitator Name</option>

                                <option value="abc" <?php if($result["nm_facilitor"]=='abc'){echo  "selected";}?>>abc</option>
                                <option value="bvd"  <?php if($result["nm_facilitor"]=='bvd'){echo "selected";}?>>bvd</option>
                                <option value="acf"  <?php if($result["nm_facilitor"]=='acf'){echo "selected";}?>>acf</option>
                                <option value="acf"  <?php if($result["nm_facilitor"]=='afd'){echo "selected";}?>>afd</option>
                            </select>
                            <br>
               

    Meeting Time  : <input type="time" id="time1" name="time1" value="<?php echo $result['time1'] ?>">

                    <input type="time" id="time2" name="time2" value="<?php echo $result['time2'] ?>"><br>
    Meeting type  : 
                    <input type="checkbox" id="ch1" name="ch1" value='Sales Kick Off Meeting' <?php echo $result['ch1'] ?>>Sales Kick Off Meeting 
                    <input type="checkbox" id="ch2" name="ch2" value='Project Discussion' <?php echo $result['ch2']?>>Project Discussion <br>

    Meeting Venue*: <input type="text" name="meeting_venu" id="meeting_venu" value="<?php echo $result['meeting_venu'] ?>"><br>
                
    Attendees*  : <select name="attendees[]" id="attendees"  multiple="multiple" size = 4  ><br>

                <option value="1" <?php if($result["attendees"]=='1'){echo "selected";}?>>Adarsh Kumar</option>
                <option value="2" <?php if($result["attendees"]=='2'){echo "selected";}?>>Abhishek Rawat</option>
                <option value="3" <?php if($result["attendees"]=='3'){echo "selected";}?>>Anamika Jain</option>
                <option value="4" <?php if($result["attendees"]=='4'){echo "selected";}?>>Anant Chouhan</option>
            </select><br>

    Non-Attendees*: <select name="non_attendees[]" id="non_attendees" multiple size = 4><br>
                        <option value="1"<?php if($result["non_attendees"]=='1'){echo "selected";}?> >Adarsh Kumar</option>
                        <option value="2"<?php if($result["non_attendees"]=='2'){echo "selected";}?> >Abhishek Rawat</option>
                        <option value="3"<?php if($result["non_attendees"]=='3'){echo "selected";}?> >Anamika Jain</option>
                        <option value="4"<?php if($result["non_attendees"]=='4'){echo "selected";}?> >Anant Chouhan</option>
                    </select><br> 

    Agenda & Discussion: <input type="text" name="agenda_discss" id="" cols="20" rows="5" value="<?php echo $result['agenda_discss'] ?>"></textarea><br>
    Decision Taken* : 
                        Decision: <input type="text" name="disicion" id="disicion" cols="20" rows="5" value="<?php echo $result['disicion']?>"/>
                        Step To be taken : <input type="text" name="step_taken" id="step_taken" cols="20" rows="5" value="<?php echo $result['step_taken']?>"/>
                        Rationale Behind the Decision: <input type="text" name="relation_behind" id="relation_behind" cols="20" rows="5" value="<?php echo $result['relation_behind'] ?>"/><br>

    Prepared By* : Vijay Arora :<input type="radio" id="perd" name="perd" value="Vijay_Arora" <?php if($result['perd'] == 'Vijay_Arora'){ echo "checked";}?>>
                   Vikas Jain :<input type="radio" id="perd" name="perd" value="Vikas_Jain" <?php if($result['perd'] == 'Vikas_Jain'){ echo "checked";} ?>><br>           

            <input type="hidden" name="oldimage" value="<?php  echo $result['myfile'];?>">
                File  *:<input type="file" name="image" id="image">
            <img src="img/<?php echo $result['myfile'];?>" width="500px" height="400px"/><br>

    Reviewed By*     :  <select name="review" id="review" ><br>
                            <option value="Vijay_Arora"<?php if($result['review'] == 'Vijay_Arora'){ echo "selected";}?>>Vijay Arora</option>
                            <option value="Vikas_Jain" <?php if($result['review'] == 'Vikas_Jain'){ echo "selected";}?>>Vikas Jain</option>
                        </select>
                        <br>
           
        <input type="submit" class="btn btn-primary " name="Update" value="submit" />
</form>


<?php 
        }
        else
        {
            echo "No Record Found  In Databsse ";
        }
    }
    else
    {
        echo "Something Wrong in Your form ";
    }
    ?>
<a href="get.php" target="_blank" class="btn-primmary">View Data</a>
</body>
</html>