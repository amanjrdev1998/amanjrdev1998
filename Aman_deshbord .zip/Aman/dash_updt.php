<?php 
include('db_config.php');

// echo "<pre>";
// print_r($_POST);
// echo "</pre>";
// die();

if(isset($_POST['Update']))
{
    $id = mysqli_real_escape_string($db_object->conn,$_POST['id']);
    $checkdata =[

        'meeting_name'=>$_POST['meeting_name'],
        'meeting_date'=> $_POST['meeting_date'],
        'nm_facilitor'=> $_POST['nm_facilitor'],
        'time1'=> $_POST['time1'],
        'time2'=> $_POST['time2'],
        'ch1' => $_POST['ch1'],
        'ch2' => $_POST['ch2'],
        'meeting_venu'=> $_POST['meeting_venu'],
        'attendees' => json_encode($_POST['attendees']),
        'non_attendees' =>json_encode($_POST['non_attendees']),
        'agenda_discss' => $_POST['agenda_discss'],
        'disicion' => $_POST['disicion'],
        'step_taken' => $_POST['step_taken'],
        'relation_behind' => $_POST['relation_behind'],
        'perd' => $_POST['perd'],
        'review' => $_POST['review'],
        'image' => $_FILES['image'],
        'oldimage' => $_POST['oldimage'],
        
    ];


    $result = $db_object->dash_update($checkdata,$id);

    if($result)
    {
        echo "DashBoard Data Update Successfully";
        header("Location: get.php");
    }
    else
    {
        echo "DashBoard Data Not Updated";
        // header("Location: view.php");
    }
}
?>
